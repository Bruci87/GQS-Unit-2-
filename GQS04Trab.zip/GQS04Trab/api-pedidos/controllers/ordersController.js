const orders = [
    { id: 1, item: 'Produto A', quantidade: 2 },
    { id: 2, item: 'Produto B', quantidade: 1 },
    { id: 3, item: 'Produto C', quantidade: 4 }
];

exports.getAllOrders = (req, res) => {
    res.status(200).json(orders);
};